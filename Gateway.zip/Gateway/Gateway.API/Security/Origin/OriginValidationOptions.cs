namespace Gateway.Api.Security.Origin;

public class OriginValidationOptions
{
    public string[] AllowedOrigins { get; set; } = [];
}
