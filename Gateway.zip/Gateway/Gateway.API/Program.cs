using System.Security.Cryptography;
using Gateway.API.Forwarding;
using Gateway.Api.Security.Cors;
using Gateway.API.Security.Csrf;
using Gateway.Api.Security.Headers;
using Gateway.Api.Security.Origin;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

Console.WriteLine("[GATEWAY] ContentRoot = " + builder.Environment.ContentRootPath);
Console.WriteLine("[GATEWAY] Environment = " + builder.Environment.EnvironmentName);

foreach (var kv in builder.Configuration.AsEnumerable())
{
    if (kv.Key.StartsWith("Jwt"))
        Console.WriteLine($"[GATEWAY CONFIG] {kv.Key} = {kv.Value}");
}

builder.Services.AddControllers();

builder.Services.AddStrongCors(builder.Configuration);

builder.Services.Configure<OriginValidationOptions>(
    builder.Configuration.GetSection("OriginValidation")
);
builder.Services.AddSingleton<IOriginValidator, OriginValidator>();

builder.Services.AddHttpClient<GatewayForwarder>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var jwtIssuer = builder.Configuration["Jwt:Issuer"];
var jwtAudience = builder.Configuration["Jwt:Audience"];

if (string.IsNullOrWhiteSpace(jwtIssuer) || string.IsNullOrWhiteSpace(jwtAudience))
{
    throw new InvalidOperationException("Jwt:Issuer or Jwt:Audience not configured");
}

var publicKeyPath = Path.Combine(
    builder.Environment.ContentRootPath,
    "Keys",
    "auth-2025-01-public.pem"
);

if (!File.Exists(publicKeyPath))
    throw new FileNotFoundException($"JWT public key not found at {publicKeyPath}");

var publicKeyPem = File.ReadAllText(publicKeyPath);

using var rsa = RSA.Create();
rsa.ImportFromPem(publicKeyPem);

var rsaKey = new RsaSecurityKey(rsa);

builder
    .Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.RequireHttpsMetadata = true;
        options.SaveToken = false;

        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = context =>
            {
                if (context.Request.Cookies.TryGetValue("access_token", out var cookieToken))
                {
                    Console.WriteLine(
                        "COOKIE TOKEN (first 100 chars): "
                            + (cookieToken?.Length > 100 ? cookieToken[..100] : cookieToken)
                    );

                    context.Token = cookieToken;
                    context.Request.Headers.Remove("Authorization");
                }
                else
                {
                    var authHeader = context.Request.Headers["Authorization"].ToString();
                    Console.WriteLine("AUTH HEADER RAW: " + authHeader);

                    if (
                        !string.IsNullOrEmpty(authHeader)
                        && authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
                    )
                    {
                        var headerToken = authHeader["Bearer ".Length..].Trim();

                        Console.WriteLine(
                            "HEADER TOKEN (first 100 chars): "
                                + (headerToken.Length > 100 ? headerToken[..100] : headerToken)
                        );

                        if (headerToken.Count(c => c == '.') == 2)
                            context.Token = headerToken;
                        else
                            context.Token = null;
                    }
                }

                return Task.CompletedTask;
            },

            OnAuthenticationFailed = ctx =>
            {
                Console.WriteLine("JWT AUTH FAILED: " + ctx.Exception);
                return Task.CompletedTask;
            },
        };

        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = rsaKey,

            ValidateIssuer = true,
            ValidIssuer = jwtIssuer,

            ValidateAudience = true,
            ValidAudience = jwtAudience,

            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(30),
        };
    });

builder.Services.AddAuthorization();

var app = builder.Build();

app.Use(
    async (ctx, next) =>
    {
        await next();
    }
);

app.UseMiddleware<SecurityHeadersMiddleware>();

app.MapSwagger().AllowAnonymous();
app.UseSwagger();
app.UseSwaggerUI();

app.UseRouting();

app.UseCors(CorsPolicyExtensions.DefaultPolicy);

app.UseMiddleware<OriginValidationMiddleware>();

app.UseAuthentication();
app.UseAuthorization();

app.UseMiddleware<CsrfProtectionMiddleware>();

app.Use(
    async (ctx, next) =>
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        await next();
        sw.Stop();
    }
);

app.MapControllers();
app.MapGet("/health", () => Results.Ok("Gateway OK"));

app.Run();
