namespace AuthService.Application.UseCases.Users;

public sealed record GetCurrentUserQuery(Guid UserId);
