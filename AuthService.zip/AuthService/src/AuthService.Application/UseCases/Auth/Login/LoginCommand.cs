namespace AuthService.Application.UseCases.Auth.Login;

public sealed record LoginCommand(string Login, string Password);
