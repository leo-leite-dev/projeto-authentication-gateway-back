namespace AuthService.Application.UseCases.Auth.Logout;

public sealed record LogoutCommand(string RefreshToken);
