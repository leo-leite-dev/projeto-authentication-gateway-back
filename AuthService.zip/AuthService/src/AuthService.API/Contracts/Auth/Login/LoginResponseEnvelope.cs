namespace AuthService.Api.Contracts.Auth.Login;

public sealed record LoginResponseEnvelope(AuthUserDto User);
