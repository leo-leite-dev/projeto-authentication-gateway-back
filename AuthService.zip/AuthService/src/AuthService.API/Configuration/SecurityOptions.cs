public class SecurityOptions
{
    public string AllowedOrigin { get; set; } = default!;
}
